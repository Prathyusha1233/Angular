export class User {
    id?: any;
    title?: string;
    description?: string;
    published?: boolean;
  }