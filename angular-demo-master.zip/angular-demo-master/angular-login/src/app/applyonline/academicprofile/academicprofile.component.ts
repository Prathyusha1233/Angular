import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-academicprofile',
  templateUrl: './academicprofile.component.html',
  styleUrls: ['./academicprofile.component.css']
})
export class AcademicprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
