import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicationreview',
  templateUrl: './applicationreview.component.html',
  styleUrls: ['./applicationreview.component.css']
})
export class ApplicationreviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
