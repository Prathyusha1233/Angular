import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-universityprofile',
  templateUrl: './universityprofile.component.html',
  styleUrls: ['./universityprofile.component.css']
})
export class UniversityprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
