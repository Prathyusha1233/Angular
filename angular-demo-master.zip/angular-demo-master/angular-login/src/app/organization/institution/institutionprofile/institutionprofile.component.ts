import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-institutionprofile',
  templateUrl: './institutionprofile.component.html',
  styleUrls: ['./institutionprofile.component.css']
})
export class InstitutionprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
